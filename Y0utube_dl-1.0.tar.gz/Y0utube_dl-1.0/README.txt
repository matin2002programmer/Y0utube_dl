Youtube_dl is a small but functional library built with the main and large youtube_dl library, in which only the video and audio download section is used.

With this library (Y0utube_dl) you can download the videos and audio you need with your desired quality.

