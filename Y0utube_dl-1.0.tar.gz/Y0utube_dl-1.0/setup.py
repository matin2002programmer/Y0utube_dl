from setuptools import setup

setup(name="Y0utube_dl", version="1.0",py_modules=["Y0utube_dl"],install_requires=['youtube_dl',
        'youtube_dl; python_version == "3.9.5"',
    ],description="Video and Audio Downloader from YouTube",
      long_description="Youtube_dl is a small but functional library built with the main and large youtube_dl library, in which only the video and audio download section is used.\n"
                       "\nWith this library (Y0utube_dl) you can download the videos and audio you need with your desired quality."
                       "\nThis is the first and new version of this small library.",
      author="Matin",author_email="mateen5671@gmail.com",ext_package="youtube_dl",url="https://t.me//dark_knight_Matin")
